var element = document.getElementById("launch-1");
var element2=document.getElementById("launch-2");
var element3=document.getElementById("launch-3");
var element4=document.getElementById("launch-4");

function popup1() {
  var x = document.getElementById("popup1");
  var y = document.getElementById("popup2");
  var z = document.getElementById("popup3");
  var zz = document.getElementById("overlay");
  // var element = document.getElementById("launch-1");
  // var element2=document.getElementById("launch-2");
  var launchText1=document.getElementsByClassName("launch-text1")[0]
  // console.log(launchText1.innerHTML)
  // console.log(element)

  element.classList.remove("blink");
  element2.classList.add("blink")
  element3.classList.remove("blink");
  element4.classList.remove("blink");
  launchText1.innerHTML="Launched"


  // if (x.style.display === "block") {
  //   x.style.display = "none";
  //   zz.style.display = "none";
  //   y.style.display = "block";
  //   z.style.display = "block";
  // } else {
    x.style.display = "block";
    y.style.display = "none";
    z.style.display = "none";
  //   zz.style.display = "block";
  // }
}
function popup2() {
  var x = document.getElementById("popup1");
  var y = document.getElementById("popup2");
  var z = document.getElementById("popup3");
  // var element2=document.getElementById("launch-2");
  // var element3=document.getElementById("launch-3");
  var launchText2=document.getElementsByClassName("launch-text2")[0]
  launchText2.innerHTML="Launched"

  element.classList.remove("blink")
  element2.classList.remove("blink")
  element4.classList.remove("blink")
  element3.classList.add("blink")

  var zz = document.getElementById("overlay");

  // if (x.style.display === "block") {
  //   x.style.display = "none";
  //   zz.style.display = "none";
  //   y.style.display = "block";
  //   z.style.display = "block";
  // } else {
    x.style.display = "none";
    y.style.display = "block";
    z.style.display = "none";
  //   zz.style.display = "block";
  // }
}
function popup3() {
  var x = document.getElementById("popup1");
  var y = document.getElementById("popup2");
  var z = document.getElementById("popup3");
  var zz = document.getElementById("overlay");
  // var element3=document.getElementById("launch-3");
  // var element4=document.getElementById("launch-4");
  var launchText3=document.getElementsByClassName("launch-text3")[0]
  launchText3.innerHTML="Launched"

  element.classList.remove("blink")
  element2.classList.remove("blink")
  element3.classList.remove("blink")
  element4.classList.add("blink")
  // if (x.style.display === "block") {
  //   x.style.display = "none";
  //   zz.style.display = "none";
  //   y.style.display = "block";
  //   z.style.display = "block";
  // } else {
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "block";
  //   zz.style.display = "block";
  // }
}
function popup4(){
  // var element4=document.getElementById("launch-4");

  element.classList.remove("blink")
  element2.classList.remove("blink")
  element3.classList.remove("blink")
  element4.classList.remove("blink")
  var launchText4=document.getElementsByClassName("launch-text4")[0]
  launchText4.innerHTML="Launched"

}
function overlay() {
  var x = document.getElementById("popup1");
  var y = document.getElementById("popup2");
  var z = document.getElementById("popup3");
  var zz = document.getElementById("overlay");
  // if (zz.style.display === "block") {
  //   x.style.display = "none";
  //   y.style.display = "none";
  //   z.style.display = "none";
  //   zz.style.display = "none";
  // } else {
  //   x.style.display = "none";
  //   y.style.display = "none";
  //   z.style.display = "none";
  //   zz.style.display = "none";
  // }
}
